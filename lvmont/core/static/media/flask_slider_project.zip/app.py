
from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    services = [
        {'id': 1, 'title': 'Klampiarske práce', 'desc': 'Precízne oplechovanie a montáž odkvapov.', 'image': 'https://via.placeholder.com/400x200'},
        {'id': 2, 'title': 'Tesárske práce', 'desc': 'Krovy, altánky, pergoly — krásne drevené konštrukcie.', 'image': 'https://via.placeholder.com/400x200'},
        {'id': 3, 'title': 'Pokrývačské práce', 'desc': 'Škridlové, plechové a trapézové krytiny pre vašu strechu.', 'image': 'https://via.placeholder.com/400x200'},
        {'id': 4, 'title': 'Rekonštrukcie striech', 'desc': 'Modernizácia starých striech bezpečne a kvalitne.', 'image': 'https://via.placeholder.com/400x200'},
        {'id': 5, 'title': 'Odvetrávané fasády', 'desc': 'Odolnosť, estetika a energetická úspora.', 'image': 'https://via.placeholder.com/400x200'},
        {'id': 6, 'title': 'Montáž strešných okien', 'desc': 'Viac svetla do podkrovia so značkami Velux, Fakro.', 'image': 'https://via.placeholder.com/400x200'},
        {'id': 7, 'title': 'Izolovanie asfaltovými pásmi', 'desc': 'Hydroizolácia proti vlhkosti pre dlhšiu životnosť.', 'image': 'https://via.placeholder.com/400x200'},
    ]
    return render_template('index.html', services=services)

@app.route('/service/<int:service_id>')
def service_detail(service_id):
    services = [
        {'id': 1, 'title': 'Klampiarske práce', 'desc': 'Detailné info o klampiarskych prácach.'},
        {'id': 2, 'title': 'Tesárske práce', 'desc': 'Detailné info o tesárskych prácach.'},
        {'id': 3, 'title': 'Pokrývačské práce', 'desc': 'Detailné info o pokrývačských prácach.'},
    ]
    service = next((s for s in services if s['id'] == service_id), None)
    if not service:
        return "Služba nenájdená", 404
    return render_template('detail.html', service=service)

if __name__ == '__main__':
    app.run(debug=True)
